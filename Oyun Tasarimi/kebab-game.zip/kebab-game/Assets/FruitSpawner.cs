using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitSpawner : MonoBehaviour
{
    public GameObject fruitPrefab;
    public float fruitSpawnRate;
    
    private float _fruitSpawnTimer;

    private void Update()
    {
        _fruitSpawnTimer += Time.deltaTime;

        if (_fruitSpawnTimer > fruitSpawnRate)
        {
            _fruitSpawnTimer = 0;
            // Spawn logic
            SpawnFruit();
        }
    }

    public void SpawnFruit()
    {
        Instantiate(fruitPrefab, transform.position, Quaternion.identity);
    }
}
