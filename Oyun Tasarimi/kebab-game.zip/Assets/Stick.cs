using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class Stick : MonoBehaviour
{
    public Transform spearSprite;
    public bool isClicked;
    public float spearSpeed;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0) && GameManager.Instance.isGameOver == false && !isClicked)
        {
            StartCoroutine(SpearEnum());
        }
    }

    IEnumerator SpearEnum()
    {
        isClicked = true;
        spearSprite.DOLocalMoveX(3.2f, spearSpeed).SetEase(Ease.OutQuart);
        yield return new WaitForSeconds(spearSpeed);
        spearSprite.DOLocalMoveX(0, spearSpeed).SetEase(Ease.InQuart);
        yield return new WaitForSeconds(spearSpeed);
        isClicked = false;
    }
}
