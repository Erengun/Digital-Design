using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using Random = UnityEngine.Random;

public class Fruit : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;
    public Sprite[] sprites;
    public Color[] tweenColors;
    private int _currentSpriteIndex;

    private void Start()
    {
        _currentSpriteIndex = Random.Range(0, sprites.Length);
        
        spriteRenderer.sprite = sprites[_currentSpriteIndex];
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "LooseCollider")
        {
            // Loose the game
            GameManager.Instance.LooseGame();
        }
        
        if (collision.gameObject.tag == "Stick")
        {
            Die();
        }
    }

    public void Die()
    {
        // TODO: Add particles
        Destroy(gameObject);
        
        Camera.main.DOColor(tweenColors[_currentSpriteIndex], 0.1f);

        GameManager.Instance.score++;
    }
}
