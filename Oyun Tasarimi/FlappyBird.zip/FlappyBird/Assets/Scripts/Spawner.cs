using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject Borular;

    public float maxHeight;
    public float minHeight;
    
    public float time;

    private void Start()
    {
        StartCoroutine(SpawnObject(time));
    }
    public IEnumerator SpawnObject(float time)
    {
        yield return new WaitUntil(() => Birdy.Instance.isStarted);
        while(!Birdy.Instance.isDead)
        {
            Instantiate(Borular, new Vector3(3, Random.Range(minHeight,maxHeight), 0), Quaternion.identity);
        
            yield return new WaitForSeconds(time);
        }
    }
}
